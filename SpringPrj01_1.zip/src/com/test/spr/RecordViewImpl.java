package com.test.spr;

import java.util.Scanner;

public class RecordViewImpl implements RecordView
{
	private Record record;

	@Override
	public void setRecord(Record record)
	{
		this.record = record;
		
	}

	@Override
	public void input()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("사용자의 이름/전화번호/주소를 입력하세요(공백구분) : ");
		String name = sc.next();
		String tel = sc.next();
		String address = sc.next();
		
		record.setName(name);
		record.setTel(tel);
		record.setAddress(address);
		
		sc.close();
		
	}

	@Override
	public void output()
	{
		System.out.printf("%s님의 전화번호는 %s, 주소는 %s입니다"
				, record.getName(), record.getTel(), record.getAddress() );
		
	}
	
	

}
