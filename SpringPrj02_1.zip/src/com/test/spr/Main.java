package com.test.spr;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main
{
	
	public static void main(String[] args)
	{
		/*
		Record rec1 = new RecordImpl1();
		
		RecordView view = new RecordViewImpl();
		
		view.setRecord(rec1);
		
		view.input();
		view.output();
		*/
		
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		RecordView view = context.getBean("view", RecordViewImpl.class);
		
		view.input();
		view.output();
		
	}
		
}
