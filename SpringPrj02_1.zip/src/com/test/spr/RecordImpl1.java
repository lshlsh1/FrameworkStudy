package com.test.spr;

public class RecordImpl1 implements Record
{
	private String name, tel, address;

	@Override
	public void setName(String name)
	{
		this.name = name;
		
	}

	@Override
	public String getName()
	{
		return name;
	}

	@Override
	public void setTel(String tel)
	{
		this.tel = tel;
		
	}

	@Override
	public String getTel()
	{
		return tel;
	}

	@Override
	public void setAddress(String address)
	{
		this.address = address;
	}

	@Override
	public String getAddress()
	{
		return address;
	}
	
	
}
