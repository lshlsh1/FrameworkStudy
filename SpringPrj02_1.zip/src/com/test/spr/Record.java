package com.test.spr;

public interface Record
{
	public void setName(String name);
	public String getName();
	
	public void setTel(String tel);
	public String getTel();
	
	public void setAddress(String address);
	public String getAddress();

}
