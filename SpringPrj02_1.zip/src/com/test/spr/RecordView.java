package com.test.spr;

public interface RecordView
{
	public void setRecord(Record record);
	
	public void input();
	
	public void output();
	
}
